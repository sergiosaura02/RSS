package dam.pmdm.examenapi_bbdd2025.api

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
 class FarmaciaResponse(var success: Boolean, var result: resultResponse) {

}
 class resultResponse (var records: List<Farmacia>) {

}
@Entity
class Farmacia (
    @PrimaryKey
    var _id : Int,
    @ColumnInfo
    var Codigo : Int,
    @ColumnInfo
    var Nombre : String,
    @ColumnInfo
    var Direccion: String,
    @ColumnInfo
    var Municipio : String,
    @ColumnInfo
    var Telefono: String

){

}
