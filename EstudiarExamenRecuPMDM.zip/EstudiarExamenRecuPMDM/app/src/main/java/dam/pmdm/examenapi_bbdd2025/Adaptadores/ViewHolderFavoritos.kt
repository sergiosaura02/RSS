package dam.pmdm.examenapi_bbdd2025.Adaptadores

import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.R

class ViewHolderFavoritos(view: View) : RecyclerView.ViewHolder(view) {
    var toolbar: Toolbar
    var codigo: TextView
    var nombre: TextView
    var direccion: TextView
    var municipio: TextView
    var telefono: TextView
    init{
        toolbar=view.findViewById(R.id.toolbarFav)
        codigo=view.findViewById(R.id.tvCodigo)
        nombre=view.findViewById(R.id.tvNombre)
        direccion=view.findViewById(R.id.tvDireccion)
        municipio=view.findViewById(R.id.tvMunicipio)
        telefono=view.findViewById(R.id.tvTelefono)
    }
}
