package dam.pmdm.examenapi_bbdd2025

import android.os.Bundle
import android.view.Menu
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.Adaptadores.FavoritosAdaptador
import dam.pmdm.examenapi_bbdd2025.api.Farmacia
import es.damiguet.daw2.examenevfinal2024.sqlite.FavoritosBBDD
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Favoritos : AppCompatActivity() {
    private lateinit var recyclerViewFavoritos: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_favoritos)
        //todo:bind
        recyclerViewFavoritos=findViewById(R.id.recyclerFavs)
        val adaptadorFavoritos= FavoritosAdaptador()

        recyclerViewFavoritos.layoutManager= LinearLayoutManager(
            applicationContext,
            LinearLayoutManager.VERTICAL,
            false)
        recyclerViewFavoritos.adapter=adaptadorFavoritos

        // Todo: Hacer que funcione eliminar
        var datosFavoritos:MutableList<Farmacia>
        adaptadorFavoritos.setAdaptadorCallback(object:FavoritosAdaptador.AdaptadorCallback{
            override fun onDeleteFavorito(far: Farmacia) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val database= FavoritosBBDD.getInstance(applicationContext)
                    database.favoritosDAO().delete(far)
                    datosFavoritos=database.favoritosDAO().selectAll() as MutableList<Farmacia>
                    withContext(Dispatchers.Main) {
                        adaptadorFavoritos.changelist(datosFavoritos)
                        adaptadorFavoritos.notifyDataSetChanged()
                    }
                }
            }

        })
        // Todo: Se vea todo
        lifecycleScope.launch(Dispatchers.IO) {
            val database= FavoritosBBDD.getInstance(applicationContext)
            datosFavoritos=database.favoritosDAO().selectAll() as MutableList<Farmacia>
            withContext(Dispatchers.Main) {
                adaptadorFavoritos.changelist(datosFavoritos)
                adaptadorFavoritos.notifyDataSetChanged()
            }
        }
    }
}