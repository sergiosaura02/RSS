/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hibernateprueba;



/**
 *
 * @author Sergio
 */
public class HibernatePrueba {

    public static void main(String[] args) {
        HibernateUtil.buildSessionFactory();
        System.out.println("Está conectado: " +  HibernateUtil.getCurrentSession().isConnected());
        HibernateUtil.closeSessionFactory();
    }
}
