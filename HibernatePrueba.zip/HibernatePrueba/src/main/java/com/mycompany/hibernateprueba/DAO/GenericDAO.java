/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.hibernateprueba.DAO;

import com.mycompany.hibernateprueba.Alumno;
import java.util.List;

/**
 *
 * @author Sergio
 */
public interface GenericDAO<T> {
    T update (Alumno a);
    boolean delete (Alumno a);
    T insert (Alumno a);
    List<Alumno> findAll (Alumno a);
    
}
