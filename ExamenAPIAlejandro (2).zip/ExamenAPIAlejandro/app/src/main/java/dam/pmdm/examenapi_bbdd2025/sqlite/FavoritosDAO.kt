package es.damiguet.daw2.examenevfinal2024.sqlite
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import dam.pmdm.examenapi_bbdd2025.api.Farmacia

@Dao
interface FavoritosDAO {
    @Query ("Select * from farmacia")
    fun selectAll():List<Farmacia>

    @Insert (onConflict = OnConflictStrategy.REPLACE)
    fun insert(fav: Farmacia): Long

    @Delete
    fun delete(fav: Farmacia)
}
