package dam.pmdm.examenapi_bbdd2025.api

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Url

interface APIservice {
    @GET
    suspend fun getFarmacias(@Url url:String): Response<FarmaciaResponse>
}