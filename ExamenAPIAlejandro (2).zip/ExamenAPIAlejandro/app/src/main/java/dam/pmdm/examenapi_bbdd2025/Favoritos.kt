package dam.pmdm.examenapi_bbdd2025

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.Adaptadores.AdaptadorFavoritos
import dam.pmdm.examenapi_bbdd2025.api.Farmacia
import es.damiguet.daw2.examenevfinal2024.sqlite.FavoritosBBDD
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Favoritos : AppCompatActivity() {
    private lateinit var recyclerViewFavoritos: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fav)

        //todo:bind
        recyclerViewFavoritos=findViewById(R.id.rvfav)
        val adaptadorFavoritos= AdaptadorFavoritos()

        recyclerViewFavoritos.layoutManager= LinearLayoutManager(
            applicationContext,
            LinearLayoutManager.VERTICAL,
            false)
        recyclerViewFavoritos.adapter=adaptadorFavoritos

        // Todo: Hacer que funcione eliminar
        var datosFavoritos:MutableList<Farmacia>
        adaptadorFavoritos.setAdaptadorCallback(object:AdaptadorFavoritos.AdaptadorCallback{
            override fun onDeleteFavorito(far: Farmacia) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val database= FavoritosBBDD.getInstance(applicationContext)
                    database.favoritosDAO().delete(far)
                    datosFavoritos=database.favoritosDAO().selectAll() as MutableList<Farmacia>
                    withContext(Dispatchers.Main) {
                        adaptadorFavoritos.changelist(datosFavoritos)
                        adaptadorFavoritos.notifyDataSetChanged()
                    }
                }
            }

        })
        // Todo: Se vea todo
        lifecycleScope.launch(Dispatchers.IO) {
            val database=FavoritosBBDD.getInstance(applicationContext)
            datosFavoritos=database.favoritosDAO().selectAll() as MutableList<Farmacia>
            withContext(Dispatchers.Main) {
                adaptadorFavoritos.changelist(datosFavoritos)
                adaptadorFavoritos.notifyDataSetChanged()
            }
        }
    }
}