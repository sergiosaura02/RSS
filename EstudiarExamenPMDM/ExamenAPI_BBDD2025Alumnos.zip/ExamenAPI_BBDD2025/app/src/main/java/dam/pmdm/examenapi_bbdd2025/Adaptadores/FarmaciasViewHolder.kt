package dam.pmdm.examenapi_bbdd2025.Adaptadores
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.R


class FarmaciasViewHolder (view: View): RecyclerView.ViewHolder(view) {
    var nombre: TextView
    var municipio:TextView

    init{
        nombre=view.findViewById(R.id.tvNombre)
        municipio=view.findViewById(R.id.tvMunicipio)
    }
}