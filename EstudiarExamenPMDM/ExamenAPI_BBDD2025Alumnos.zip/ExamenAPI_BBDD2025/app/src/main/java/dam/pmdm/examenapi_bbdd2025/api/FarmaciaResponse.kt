package dam.pmdm.examenapi_bbdd2025.api

import androidx.room.Entity
import androidx.room.PrimaryKey

class FarmaciaResponse(var success: Boolean, var result: resultResponse) {
}

class resultResponse (var records: List<Farmacia>) {

}
class Farmacia (){

}
