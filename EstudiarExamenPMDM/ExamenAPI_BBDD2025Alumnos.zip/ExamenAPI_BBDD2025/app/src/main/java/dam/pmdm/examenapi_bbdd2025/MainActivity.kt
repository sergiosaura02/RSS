package dam.pmdm.examenapi_bbdd2025

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.api.Farmacia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_examen, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbarPrincipal))
        supportActionBar?.setDisplayShowTitleEnabled(false);
        //bind
    }


    // var call = getRetrofit().create(APIservice::class.java).getFarmacias("datastore_search_sql?sql=SELECT%20*%20from%20%22459b23f1-b239-49f5-\n" +
    //                    "a4b9-c325d66e2799%22%20WHERE%20%22Municipio%22%20LIKE%20%27%$cadena%%27")


    private fun mostrarDialogGuardado(farm: Farmacia) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Guardar Farmacia en Favoritos")
        builder.setMessage("¿Deseas guardar esta farmacia en favoritos?")

        builder.setPositiveButton("Guardar") { _, _ ->

        }
        builder.setNegativeButton("Cancelar") { _, _ ->
        }
        val dialog = builder.create()
        dialog.show()

    }

}