package dam.pmdm.examenapi_bbdd2025.Adaptadores

import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.R

class FavoritosViewHolder (view: View): RecyclerView.ViewHolder(view) {
    var codigo: TextView
    var nombre: TextView
    var direccion: TextView
    var municipio: TextView
    var telefono: TextView
    var toolbarFavoritos: Toolbar

    init{
        codigo=view.findViewById(R.id.tfCodigo)
        nombre=view.findViewById(R.id.tfNombre)
        direccion=view.findViewById(R.id.tfDireccion)
        municipio=view.findViewById(R.id.tfMunicipio)
        telefono=view.findViewById(R.id.tfTelefono)
        toolbarFavoritos=view.findViewById(R.id.toolbarFav)
    }

}