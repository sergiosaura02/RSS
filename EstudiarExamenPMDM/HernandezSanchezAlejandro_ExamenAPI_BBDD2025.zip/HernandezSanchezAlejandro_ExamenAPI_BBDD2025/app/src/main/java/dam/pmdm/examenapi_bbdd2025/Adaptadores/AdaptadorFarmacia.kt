package dam.pmdm.examenapi_bbdd2025.Adaptadores

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.MainActivity
import dam.pmdm.examenapi_bbdd2025.R
import dam.pmdm.examenapi_bbdd2025.api.Farmacia

class AdaptadorFarmacia : RecyclerView.Adapter<FarmaciasViewHolder>() {
    private var far: List<Farmacia> = ArrayList()
    private lateinit var listener: AdaptadorCallback
    interface AdaptadorCallback {
        fun onSafeFar(far: Farmacia)
    }
    fun setAdaptadorCallback(listener: AdaptadorCallback) {
        this.listener=listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FarmaciasViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        var viewHolder = FarmaciasViewHolder(layoutInflater.inflate(R.layout.fila_farmacia, parent, false))
        return viewHolder
    }

    override fun getItemCount(): Int = far.size
    override fun onBindViewHolder(holder: FarmaciasViewHolder, position: Int) {
        val item = far[position]
        holder.nombre.text = item.Nombre
        holder.municipio.text = item.Municipio
        holder.itemView.setOnClickListener {
            listener.onSafeFar(item)
        }
    }

    fun changelist(farmacia: List<Farmacia>) {
        far=farmacia
    }
}