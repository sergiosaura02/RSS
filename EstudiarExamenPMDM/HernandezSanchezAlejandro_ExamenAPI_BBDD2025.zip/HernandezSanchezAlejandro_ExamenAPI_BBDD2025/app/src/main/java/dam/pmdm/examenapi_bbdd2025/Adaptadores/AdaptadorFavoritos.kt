package dam.pmdm.examenapi_bbdd2025.Adaptadores

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.R
import dam.pmdm.examenapi_bbdd2025.api.Farmacia

class AdaptadorFavoritos : RecyclerView.Adapter<FavoritosViewHolder>() {
    private var fav: List<Farmacia> = ArrayList()
    private lateinit var listener: AdaptadorCallback
    interface AdaptadorCallback {
        fun onDeleteFavorito(far: Farmacia)
    }
    fun setAdaptadorCallback(listener: AdaptadorCallback) {
        this.listener=listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoritosViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        var viewHolder = FavoritosViewHolder(layoutInflater.inflate(R.layout.fila_favoritos, parent, false))
        viewHolder.toolbarFavoritos.inflateMenu(R.menu.menu_fav)
        return viewHolder
    }

    override fun getItemCount(): Int = fav.size
    override fun onBindViewHolder(holder: FavoritosViewHolder, position: Int) {
        val item = fav[position]
        holder.codigo.text = item.Codigo
        holder.nombre.text = item.Nombre
        holder.direccion.text = item.Direccion
        holder.municipio.text = item.Municipio
        holder.telefono.text = item.Telefono
        holder.toolbarFavoritos.setOnMenuItemClickListener {
            when(it.itemId) {
                R.id.action_borrar -> {
                    //borrar en BBDD
                    listener.onDeleteFavorito(item)
                    true
                }
                else ->{
                    true
                }
            }
        }
    }

    fun changelist(far: List<Farmacia>) {
        fav=far
    }
}