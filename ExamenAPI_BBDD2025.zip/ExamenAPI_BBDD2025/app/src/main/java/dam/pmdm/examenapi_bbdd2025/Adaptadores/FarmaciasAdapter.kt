package dam.pmdm.examenapi_bbdd2025.Adaptadores

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.R
import dam.pmdm.examenapi_bbdd2025.api.Farmacia

class FarmaciasAdapter: RecyclerView.Adapter<FarmaciasViewHolder>() {
    private var farmacias: List<Farmacia> = ArrayList()
    private lateinit var listener: AdaptadorCallback
    interface AdaptadorCallback {
        fun onSafeFarmacia(farmacia: Farmacia)
    }
    fun setAdaptadorCallback(listener: AdaptadorCallback) {
        this.listener=listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FarmaciasViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        var viewHolder = FarmaciasViewHolder(layoutInflater.inflate(R.layout.fila_farmacia, parent, false))
        return viewHolder
    }

    override fun getItemCount(): Int = farmacias.size

    override fun onBindViewHolder(holder: FarmaciasViewHolder, position: Int) {
        var farmacia = farmacias[position]
        holder.nombre.text = farmacia.Nombre
        holder.municipio.text = farmacia.Municipio
        holder.itemView.setOnClickListener {
            listener.onSafeFarmacia(farmacia)
        }
    }
    fun changelist(far: List<Farmacia>) {
        farmacias=far
        notifyDataSetChanged()
    }

}