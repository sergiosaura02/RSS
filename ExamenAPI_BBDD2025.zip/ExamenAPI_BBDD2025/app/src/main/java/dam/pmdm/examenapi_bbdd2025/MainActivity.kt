package dam.pmdm.examenapi_bbdd2025

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Adapter
import dam.pmdm.examenapi_bbdd2025.Adaptadores.FarmaciasAdapter
import dam.pmdm.examenapi_bbdd2025.Adaptadores.FarmaciasViewHolder
import dam.pmdm.examenapi_bbdd2025.api.APIservice
import dam.pmdm.examenapi_bbdd2025.api.Farmacia
import es.damiguet.daw2.examenevfinal2024.sqlite.FavoritosBBDD
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity(), androidx.appcompat.widget.SearchView.OnQueryTextListener {
    var adaptadorFarmacias = FarmaciasAdapter()
    private lateinit var recyclerView: RecyclerView
    private lateinit var buscador : SearchView
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_examen, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Todo: cambiar a FAVORITOS
        when (item.itemId) {
            R.id.favs -> {
                val intent = Intent(this, Favoritos::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbarPrincipal))
        supportActionBar?.setDisplayShowTitleEnabled(false);
        //bind

        recyclerView = findViewById(R.id.rvfarms)
        buscador = findViewById(R.id.svfarms)
        buscador.setOnQueryTextListener(this)
        recyclerView.layoutManager = LinearLayoutManager(
            applicationContext,
            LinearLayoutManager.VERTICAL, false
        )
        recyclerView.adapter = adaptadorFarmacias
        adaptadorFarmacias.setAdaptadorCallback(object : FarmaciasAdapter.AdaptadorCallback {
            override fun onSafeFarmacia(farmacia: Farmacia) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val database = FavoritosBBDD.getInstance(applicationContext)
                    database.favoritosDAO().insert(farmacia)
                }
            }

        })

    }



    private fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://datosabiertos.regiondemurcia.es/api/action/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    private fun busquedaFarmacias(query: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            val call = getRetrofit().create(APIservice::class.java)
                .getFarmacias("datastore_search_sql?sql=SELECT%20*%20from%20%22459b23f1-b239-49f5-a4b9-c325d66e2799%22%20WHERE%20%22Municipio%22%20LIKE%20%27%$query%%27")
            val farmaciasAPI = call.body()
            if (call.isSuccessful) {
                val farmacias = farmaciasAPI?.result?.records?: emptyList()
                withContext(Dispatchers.Main) {
                    adaptadorFarmacias.changelist(farmacias)
                    adaptadorFarmacias.notifyDataSetChanged()
                }
            } else {
                Toast.makeText(applicationContext, "error API", Toast.LENGTH_SHORT).show()
            }

        }
    }



    private fun mostrarDialogGuardado(farm: Farmacia) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Guardar Farmacia en Favoritos")
        builder.setMessage("¿Deseas guardar esta farmacia en favoritos?")

        builder.setPositiveButton("Guardar") { _, _ ->
            lifecycleScope.launch(Dispatchers.IO) {
                val database = FavoritosBBDD.getInstance(applicationContext)
                database.favoritosDAO().insert(farm)
            }
        }
        builder.setNegativeButton("Cancelar") { _, _ ->
        }
        val dialog = builder.create()
        dialog.show()

    }
    override fun onQueryTextSubmit(query: String?): Boolean {
        if (!query.isNullOrEmpty()) {
            busquedaFarmacias(query)
        }
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(this.buscador.windowToken, 0)
        return true
    }

    override fun onQueryTextChange(newText: String?): Boolean {
        return true
    }

}