package dam.pmdm.examenapi_bbdd2025.Adaptadores

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import dam.pmdm.examenapi_bbdd2025.Favoritos
import dam.pmdm.examenapi_bbdd2025.R
import dam.pmdm.examenapi_bbdd2025.api.Farmacia

class FavoritosAdaptador: RecyclerView.Adapter<ViewHolderFavoritos>() {
    private var favoritos: List<Farmacia> = ArrayList()
    private lateinit var listener: AdaptadorCallback
    interface AdaptadorCallback {
        fun onDeleteFavorito(favorito: Farmacia)
    }
    fun setAdaptadorCallback(listener: AdaptadorCallback) {
        this.listener=listener
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderFavoritos {
        val layoutInflater = LayoutInflater.from(parent.context)
        var viewHolder = ViewHolderFavoritos(layoutInflater.inflate(R.layout.fila_favoritos, parent, false))
        viewHolder.toolbarFavoritos.inflateMenu(R.menu.menu_fav)
        return viewHolder
    }

    override fun getItemCount(): Int = favoritos.size

    override fun onBindViewHolder(holder: ViewHolderFavoritos, position: Int) {
        val fav = favoritos[position]
        holder.codigo.text = fav.Codigo.toString()
        holder.nombre.text = fav.Nombre
        holder.direccion.text = fav.Direccion
        holder.municipio.text = fav.Municipio
        holder.telefono.text = fav.Telefono
        holder.toolbarFavoritos.setOnMenuItemClickListener {
            when(it.itemId) {
                R.id.action_borrar -> {
                    //borrar en BBDD
                    listener.onDeleteFavorito(fav)
                    true
                }
                else ->{
                    true
                }
            }
        }
    }
    fun changelist(far: List<Farmacia>) {
        favoritos=far
    }

}